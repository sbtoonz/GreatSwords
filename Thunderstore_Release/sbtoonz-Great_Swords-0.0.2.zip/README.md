![](https://media.discordapp.net/attachments/834731701023670283/1092999634357600396/image.png)

<div style="text-align: center;">

# 2H Great Swords 

A New mix of 2H swords brought to you by LittleRoom.dev
You can find 4x 2h swords meant to round out the vanilla gameplay style. 


</div>
<div style="text-align: center;">
<details>
<summary> Release Notes</summary>

# V0.0.1
* Initial Mod Release


</details>
</div>

<div style="text-align: center;">
<details>
<summary> Details: </summary>
<br>
<div style="text-align: center; text-indent: 5mm">
<details>
<summary>
BlackMetal Sword
</summary>

### BlackMetal GreatSword
![](https://media.discordapp.net/attachments/834731701023670283/1092991350506520586/image.png)

#### Recipe:
- BlackMetal: 40
- Red Jute: 4
- Fine Wood: 2

<br>

Prefab Name 
```Sword_GreatBlackmetal```

<br>
<br>
</details>

<details>
<summary>
Bronze GreatSword
</summary>

### Bronze GreatSword
![](https://media.discordapp.net/attachments/834731701023670283/1092990698195787916/image.png?width=1171&height=461)

#### Recipe:
- Bronze : 15
- Wood: 2
- Leather Scraps: 4

<br>

Prefab Name:
```Sword_GreatBronze```

<br>
<br>

</details>

<details>
<summary>
Iron GreatSword
</summary>

### Iron GreatSword
![](https://media.discordapp.net/attachments/834731701023670283/1092989112836964443/image.png?width=1171&height=551)

#### Recipe:
- Iron: 30
- Wood: 2
- Leather Scraps: 4

<br>

Prefab Name
```Sword_GreatIron```
<br>
<br>

</details>

<details>
<summary>
Silver GreatSword
</summary>

### Silver GreatSword
![](https://media.discordapp.net/attachments/834731701023670283/1092989995020734495/image.png?width=1171&height=556)

#### Recipe:
- Silver: 30
- Wood: 2
- Leather Scraps: 4
- Iron: 10

<br>

PrefabName
```Sword_GreatSilver```

<br>
<br>

</details>
</div>
</details>
</div>